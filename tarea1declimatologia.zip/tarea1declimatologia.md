```python
import numpy as np
import xarray as xr
import matplotlib.pyplot as plt
from scipy import stats
import datetime
import matplotlib.dates as mdates
from dateutil.relativedelta import relativedelta
```

    Matplotlib is building the font cache; this may take a moment.
    


```python
precipitacion = np.loadtxt('/Users/Hendrickson/Desktop/climatolgia/tareaclima1.txt')
```


```python
plt.plot(precipitacion, color='b')
```




    [<matplotlib.lines.Line2D at 0x1884834afd0>]




    
![png](output_2_1.png)
    



```python
def anom(data_cal, data_full, option):
    data_clim = np.ma.zeros(12)
    dataf = int(len(data_full)/12)
    
    for i in range(12):
        data_clim[i] = np.ma.mean(data_cal[i::12],axis=0)
        
    data_clim2 = np.tile(data_clim, (dataf))
    data_anom = np.zeros_like(dataf)
    
    if option == 'temp':
        data_anom = data_full - data_clim2
    
    else:
        data_anom = data_full / data_clim2
    return data_anom
```


```python
anomalia = anom(precipitacion, precipitacion, "temp")
```


```python
plt.plot(anomalia, color='red')
```




    [<matplotlib.lines.Line2D at 0x18849f04910>]




    
![png](output_5_1.png)
    



```python
tiempo = np.arange(0,816,1)
pendiente = stats.linregress(tiempo, anomalia)[0]
valorp = stats.linregress(tiempo, anomalia)[3]
```


```python
inter = stats.linregress(tiempo, anomalia)[1]
```


```python
start = datetime.date(1939, 1, 1)
dates = [start + relativedelta(months=n) for n in range(0,816)]
formatter = mdates.DateFormatter("%Y") ### formatter of the date
locator = mdates.YearLocator() ### where to put the labels
plt.figure(figsize=(15,10))
ax1 = plt.subplot(321)
plt.plot(dates, anomalia[:], lw=2.5, color='darkred', label='Anomalia')
plt.ylabel('mm/mes',fontsize=20, fontweight='bold')
plt.yticks(fontsize=20)
plt.xticks(fontsize=20)
plt.xlim([dates[0],dates[815]])
plt.ylim([-80,210])
plt.title('Anomalías de precipitación', fontsize=26,fontweight='bold',y=1.05)
plt.grid()
ax2 = plt.subplot(322)
plt.plot(dates, precipitacion[:], lw=2.5, color='royalblue', label='Anomalia')
plt.ylabel('mm/mes',fontsize=20, fontweight='bold')
plt.yticks(fontsize=20)
plt.xticks(fontsize=20)
plt.xlim([dates[0],dates[815]])
plt.ylim([0,410])
plt.title('Precipitación total mensual', fontsize=26,fontweight='bold',y=1.05)
plt.grid()
plt.tight_layout(pad=2.4, w_pad=1.5, h_pad=2.5)
```


    
![png](output_8_0.png)
    




**a) ¿Cual es la tendencia de los datos analizados? ¿Es positiva o negativa?**

La tendencia de los datos de precipitación mensual analizados muestra un ligero aumento con el tiempo, por lo que la tendencia es **positiva.**


**b) ¿Qué implicación tiene esta tendencia?**

Una tendencia positiva en la precipitación implica que, con el paso del tiempo, la región ha experimentado un incremento en la cantidad promedio de lluvia mensual. Esto puede tener varias implicaciones climatológicas y ambientales, tales como:

-Mayor disponibilidad de agua en el ecosistema y en recursos hídricos.

-Cambios en la vegetación y en los patrones agrícolas.

-Posibles aumentos en eventos extremos relacionados con la lluvia, como inundaciones.

**c) ¿Cuál es la desviación estándar?**
La desviación estándar de los datos de precipitación mensual es de aproximadamente 51 mm/mes.


```python
np.std(precipitacion)
```




    np.float64(51.232482053415474)







**NOMBRE Y APELLIDO**
 HENDRICKSON MANUEL MERCEDES LARA
 
 **MATRICULA**
   100654974

  **MATERIA**
  CLIMATOLOGIA II
